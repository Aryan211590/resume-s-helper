import React from 'react'
import Templatethree from './Templates/TemplatefourF/Templatefour.jsx';
const Templatefourmain = () => {
  return (
   <>
   <Templatethree/>
   </>
  )
}

export default Templatefourmain