import React from 'react'
import Deep from './Deep'
import Resumeheader from './Resumeheader'
const ExpTemp = () => {
    return (
        <div>
            <Resumeheader />
            <Deep />
        </div>
    )
}

export default ExpTemp