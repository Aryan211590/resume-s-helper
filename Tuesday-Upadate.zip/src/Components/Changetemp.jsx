import React from "react";
import ContactInformation from "./ContactInformation";

const Changetemp = () => {
  return (
    <div>
    <ContactInformation/>
    </div>
  );
};

export default Changetemp;
