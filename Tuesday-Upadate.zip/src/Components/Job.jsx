import React from 'react'
import Jobheader from './Jobheader'
import Jobsearch from './User/Jobs/Jobsearch'

const Job = () => {
  return (
    <>
    <Jobheader/>
    <Jobsearch/>
    </>
  )
}

export default Job