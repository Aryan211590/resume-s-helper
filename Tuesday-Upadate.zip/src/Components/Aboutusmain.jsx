import React from 'react'
import About from './About/About';
const Aboutusmain = () => {
  return (
    <>
    <About/>
    </>
  )
}

export default Aboutusmain