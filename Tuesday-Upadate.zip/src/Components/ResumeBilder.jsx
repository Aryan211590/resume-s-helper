import React from 'react';
import Footer from './Footer';
import Header from './Header';
import { PlanPremium } from './Ourplans/PlanPremium ';
import Page2_first_section from './Page2_first_section';
const ResumeBilder = () => {
  return (
    <>
    <Header/>
      <Page2_first_section/>
      <PlanPremium/>
    <Footer />
    </>
  );
};

export default ResumeBilder;
