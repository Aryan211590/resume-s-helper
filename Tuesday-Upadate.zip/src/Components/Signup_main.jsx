import React from 'react'

const Signup_main = () => {
  return (
    <div>Signup_main</div>
  )
}

export default Signup_main