import React from 'react';
import Firstpage from './Blogs/blogpages/Firstpage';
import Footer from './Footer';
import Header from './Header';
const Blogfirst = () => {
  return (
      <>
      <Header/>
        <Firstpage/>
      <Footer/>
      </>
  );
};

export default Blogfirst;
