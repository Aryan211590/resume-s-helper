const Blogarray =[
    {
        Key:1,
        heading:"How to Highlight Communication Skills in your Resume",
        content:"   Communication skills are something that is desired and required for every post. You clearly can’t get through the work environment if you lack communication skills and moreover you won’t be able to make it to your final round of interviews.",
        linkTo:"/Blog/communication-skill",
    },
    {
        Key:2,
        heading:"How to Showcase Leadership Strengths on a Resume",
        content:"'How to Highlight Leadership Strengths on your Resume 'Leadership is the art of getting someone else to do something you want done because he wants to do it Dwight D. Eisenhower",
        linkTo:"/Blog/leadership",
    },
    {
        Key:3,
        heading:"How to Write Thank You Email after Interview",
        content:"Just nailed your interview and you have now walked out of the office. You think the task is done, but no, it isn’t over yet. Most hiring managers look forward to a thank you email as soon as you leave the building. A thank you email is the cherry on a cake right after giving a killer performance in the interview. ",
        linkTo:"/Blog/thankyou",
    },
    {
        Key:4,
        heading:"Importance of Extracurricular Activities on Your Resume",
        content:" Extracurricular activities are the ones where you develop valuable skills and qualities like leadership skills. These are the activities where you engage more with people and hence help build an overall great personality.",
        linkTo:"/Blog/activities",
    },
    {
        Key:5,
        heading:"Most Common Mistakes when Writing a Resume",
        content:"We all go crazy over getting our dream job. Applying to every possible company for the post. Guess what, you aren’t getting any responses. We will tell you why. It’s likely because you must have made very common mistakes while writing your resume which ultimately has upset the hiring managers.",
        linkTo:"/Blog/mistakes",
    },
    {
        Key:6,
        heading:"Tips for Writing your First Resume ",
        content:"  We are sure you won’t be the first person sitting in front of a screen with a blank word document struggling to write your first resume. We believe you, filling those one or two pages might seem to you the most consuming task. ",
        linkTo:"/Blog/writingtips",
    },
    {
        Key:7,
        heading:"Top 10 Tips for a Job Interview",
        content:" Job interviews are scary. You're put on the spot. One question follows another and you feel nervous and find yourself trapped there but we have for you 10 amazing tips to cool off yourself a bit. You might flaunt your skills in your resume ",
        linkTo:"/Blog/interviewtips",
    },
    {
        Key:8,
        heading:"How to Showcase Leadership Strengths on a Resume ",
        content:"'How to Highlight Leadership Strengths on your Resume' Leadership is the art of getting someone else to do something you want done because he wants to do it Dwight D. Eisenhower",
        linkTo:"/Blog/showcase",
    },
]
export default Blogarray ;