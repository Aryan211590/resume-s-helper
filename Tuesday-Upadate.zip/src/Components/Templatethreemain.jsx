import React from 'react'
import Templatethree from './Templates/TemplatethreeF/Templatethree';
const Templatethreemain = () => {
  return (
    <Templatethree/>
  )
}

export default Templatethreemain