import React from 'react'

const New = () => {
    return (
        <div>

        </div>
    )
}

export default New; 