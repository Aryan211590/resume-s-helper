import React from 'react'
import Templatefive from './Templates/TemplatefiveF/Templatefive.jsx';
const Templatefivemain = () => {
  return (
    <>
    <Templatefive/>
    </>
  )
}

export default Templatefivemain