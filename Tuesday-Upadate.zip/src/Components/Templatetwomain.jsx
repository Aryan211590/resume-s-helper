import React from 'react'
import Templatetwo from './Templates/Templatetwo/Templatetwo';
const Templatetwomain = () => {
  return (
   <Templatetwo/>
  )
}
export default Templatetwomain