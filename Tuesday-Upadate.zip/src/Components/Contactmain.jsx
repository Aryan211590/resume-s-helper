import React from 'react'
import Contact from './contactus/Contact';
import Contacts2 from './contactus/Contacts2';
const Contactmain = () => {
  return (
    <>
    <Contact/>
    <Contacts2/>
    </>
  )
}
export default Contactmain