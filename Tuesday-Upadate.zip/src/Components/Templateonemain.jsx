import React from 'react'
import Templateone from './Templates/Templatetwo/Templatetwo';
const Templateonemain = () => {
  return (
<>
<Templateone/>
</>
  )
}

export default Templateonemain