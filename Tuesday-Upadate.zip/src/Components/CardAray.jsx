const CardAray=[
    {
        key:1,
        Title:'1',
        bold:'Pick a standout resume template',
        para:"Choose from a range of styles and colors and get noticed"
    },
    {
        key:2,
        Title:'2',
        bold:'Add your winning personality',
        para:"Follow expert tips and examples to make your resume shine!"
    },
    {
        key:3,
        Title:'3',
        bold:'Start applying for jobs!',
        para:"Send your resume and start preparing for your job interviews!"
    },
   
]
export default CardAray;