import React, { useState, useEffect, useRef, createRef } from "react";
import { useReactToPrint } from "react-to-print";
import { PDFExport } from "@progress/kendo-react-pdf";
import Education from "./Education";
import { MdOutlineVibration, MdOutlineFormatLineSpacing } from "react-icons/md";
import { BsPlusLg } from "react-icons/bs";
import { HiMinus } from "react-icons/hi";
import { AiOutlineBgColors } from "react-icons/ai";
import { BiText } from "react-icons/bi";
import { MdTextFields } from "react-icons/md";
import AliceCarousel from "react-alice-carousel";
import { ImCross } from "react-icons/im";
import {
  AiOutlineLink,
} from "react-icons/ai";
import {
  Col,
  Offcanvas,
  Row,
  OverlayTrigger,
  Button,
  Popover,
  Container
} from "react-bootstrap";

import "react-tabs/style/react-tabs.css";
import {
  AiFillCaretDown,
  AiTwotoneMail,
} from "react-icons/ai";
import { Link } from "react-router-dom";
import Todo from "./Todo";
import { GoDesktopDownload } from "react-icons/go";
import "react-responsive-carousel/lib/styles/carousel.min.css";
import temp1 from "./images/template1.png";
import template2 from "./images/template2.png";
import template3 from "./images/template3.png";
import template4 from "./images/template4.png";
import template5 from "./images/template5.png";
import { BsTelephoneFill } from "react-icons/bs";
import { useNavigate } from "react-router-dom";
import { ImLocation2 } from "react-icons/im";
import Experince from "./Experince";
import "react-alice-carousel/lib/alice-carousel.css";

const Language = ({ langua, index, completelangua, removelangua }) => {
  console.log(langua, 'lang')
  return (
    <div>

      <div
        className="langua"
        style={{ textDecoration: langua.isCompleted ? "line-through" : "" }}
      >

        <ul id="Skilla2">
          <li id="Skilla223">{langua}<button id="removelangua" onClick={() => removelangua(index)}>x</button></li>
        </ul>
        {/* <div>
                  <button onClick={() => removelangua(index)}>x</button>
              </div> */}
      </div>
    </div>
  )
}
function ADdSkill({ Skilla, index, removeSkilla }) {
  console.log(Skilla, index, 'i am here')
  if (Skilla)
    return (
      <div
        className="ADdSkill"
        style={{ textDecoration: Skilla.isCompleted ? "line-through" : "" }}
      >
        <ul id="Skilla2">
          <li id="Skilla23">
            {Skilla}
            <button id="removeSkilla" onClick={() => removeSkilla(index)}>
              x
            </button>
          </li>
        </ul>
      </div>
    );
}

function SkillaForm({ addSkilla }) {
  const [value, setValue] = React.useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!value) return;
    addSkilla(value);
    setValue("");
  };

  return (
    <form onSubmit={handleSubmit} className="d-flex cus-border-main">
      <input
        type="text"
        className="input"
        value={value}
        onChange={(e) => setValue(e.target.value)}
      />
      <button className="add-btn add-btn-cus-u  button-z" type="submit">
        Add
      </button>
    </form>
  );
}
const NewComponent = (props) => {
  // header here
  // const todoos = JSON.parse(localStorage.getItem("todoos"));
  const now = 10;

  const [isActive, setIsActive] = useState(true);
  const [state, setState] = React.useState({
    name: "",
    LastName: "",
    occupation: "",
    aboutus: "",
    email: "",
    address: "",
    phone: "",
    date: "",
    nationality: "",
    link: "",
    Collage: "",
    Qualification: "",
    CollageStart: "",
    CollageLast: "",
    Board: "",
    AboutEDUCATION: "",
  });

  if (localStorage.getItem("contact_info") !== null && localStorage.getItem("contact_info_state") == 'true') {
    hello_kity()
    
  }
  let navigate = useNavigate();
  // ajax api call
  let submit_resume = async (e) => {
    e.preventDefault();
    try {
      let res = await fetch("http://54.177.234.91:8000/api/add-user-resume", {
        method: "POST",
        crossDomain: true,
        headers: {
          "Content-Type": "application/json",
          Authorization: "token " + localStorage.getItem("sdfsafdsfsafa"),
        },
        body: JSON.stringify({
          info: state,
          skill: Skillas,
          resume_id: toggleState,
        }),
      });
      let resJson = await res.json();
      console.log("*********", toggleState);
      if (res.status === 200) {
        alert("criminal");
      } else {
        alert(res.msg);
        // alert("Email and Paswword are Incorect")
      }
    } catch (err) {
      console.log(err);
    }
  };
  const ref = createRef();

  const [Skillas, setSkillas] = React.useState([
    {
      text: "",
    },
  ]);

  const addSkilla = (text) => {
    const newSkillas = [...Skillas, { text }];
    setSkillas(newSkillas);
  };

  const completeSkilla = (index) => {
    const newSkillas = [...Skillas];
    newSkillas[index].isCompleted = true;
    setSkillas(newSkillas);
  };

  const removeSkilla = (index) => {
    const newSkillas = [...Skillas];
    newSkillas.splice(index, 1);
    setSkillas(newSkillas);
  };
  // Add NEw SEction
  let initTodoe;

  if (localStorage.getItem("Eduac") === null) {
    initTodoe = [];
  } else {
    initTodoe = JSON.parse(localStorage.getItem("Eduac"));
  }

  const onDelete2 = (etodo) => {
    console.log("I am onDelete2 of todo", etodo);

    setEduac(
      Eduac.filter((e) => {
        return e !== etodo;
      })
    );

    localStorage.setItem("Eduac", JSON.stringify(Eduac));

  };

  const addTodo2 = (
    title,
    descc,
    SDate,
    LDate,
    Eduaction,
    schooll,
    Locationnn
  ) => {
    console.log(
      "I am adding this todo",
      title,
      descc,
      SDate,
      schooll,
      LDate,
      Locationnn
    );
    let snoo;
    if (Eduac.length === 0) {
      snoo = 0;
    } else {
      snoo = Eduac[Eduac.length - 1].snoo + 1;
    }
    const myTodo = {
      snoo: snoo,
      title: title,
      descc: descc,
      SDate: SDate,
      LDate: LDate,
      Eduaction: Eduaction,
      schooll: schooll,
      Locationnn: Locationnn,
    };

    setEduac([...Eduac, myTodo]);
    console.log(myTodo);
  };
  // =========================================Eduaction End=====================================

  const [Eduac, setEduac] = useState(initTodoe);

  useEffect(() => {
    localStorage.setItem("Eduac", JSON.stringify(Eduac));
  }, [Eduac]);

  // Add NEw SEction
  // ==========================Download Property ===================
  // const container = React.useRef(null);
  const pdfExportComponent = React.useRef(1);

  const exportPDFWithComponent = () => {
    var subscription = localStorage.getItem("txteget");
    var login_state = localStorage.getItem("fvxzvxvxzvzx");
    if (login_state === "true") {
      if (subscription == "true") {
        if (pdfExportComponent.current) {
          pdfExportComponent.current.save();
        }
      } else if (subscription == "false") {
        navigate(`/Planproductmain`);
      } else {
        alert("error");
      }
    } else {
      navigate(`/login`);
    }
    // if (pdfExportComponent.current) {
    //     pdfExportComponent.current.save();
    // }
  };
  // ==========================Download Property ===================

  // ===========================FontSize change=====================
  const [fontSize, updateFontSize] = useState("16px");

  function handleClick() {
    updateFontSize((fontSize) => `${parseInt(fontSize) + 5}px`);
  }

  function handleClick2() {
    updateFontSize((fontSize) => `${parseInt(fontSize) - 5}px`);
  }


  const [show, setShow] = useState(false);
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  // =============================Taplate SHow End=====================

  const [toggleState, setToggleState] = useState(1);

  const toggleTab = (index) => {
    setToggleState(index);
  };
  const getActiveClass = (index, className) =>
    toggleState === index ? className : "";

  // =======================Add Section (Todo) State Start 2 =============================

  const [NextState, setNextState] = useState(1);
  let Deep;
  if (NextState == 1) {
    Deep = "Contact Information";
  } else if (NextState == 2) {
    Deep = "Experience";
  } else if (NextState == 4) {
    Deep = "Education";
  } else if (NextState == 5) {
    Deep = "Add another";
  } else if (NextState == 6) {
    Deep = "Skills - Languages";
  }
  const NexttoggleTab = (index) => {
    setNextState(index);
    if (index > NextState) {
      setCountOfProgess((oldProgress) => {
        if (100 == oldProgress)
          return alert("congratulations your Resume Is Ready TO download");
        return Math.min(oldProgress + 30, 100);
      });
    } else {
      console.log("click me");
      setCountOfProgess((oldProgress) => {
        if (100 == oldProgress)
          return alert("congratulations your Resume Is Ready TO download");
        return Math.min(oldProgress - 30, 100);
      });
    }
  };
  const getActiveClasss = (index, className) =>
    NextState === index ? className : "";

  // =======================Add Section (Todo) State Start=============================

  let initTodo;
  if (localStorage.getItem("todos") === null) {
    initTodo = [];
  } else {
    initTodo = JSON.parse(localStorage.getItem("todos"));
  }

  const onDelete = (todo) => {
    console.log("I am ondelete of todo", todo);

    setTodos(
      todos.filter((e) => {
        return e !== todo;
      })
    );
    console.log("deleted", todos);
    localStorage.setItem("todos", JSON.stringify(todos));
  };

  const addTodo = (title, desc) => {
    console.log("I am adding this todo", title, desc);
    let sno;
    if (todos.length === 0) {
      sno = 0;
    } else {
      sno = todos[todos.length - 1].sno + 1;
    }
    const myTodo = {
      sno: sno,
      title: title,
      desc: desc,
    };
    setTodos([...todos, myTodo]);
    console.log(myTodo);
  };

  const [todos, setTodos] = useState(initTodo);
  useEffect(() => {
    localStorage.setItem("todos", JSON.stringify(todos));
  }, [todos]);

  // =======================Add Section (Todo) State Start=============================

  // ===========================Print Functin Start===========================================
  const componentRef = useRef();
  const handlePrint = useReactToPrint({
    content: () => componentRef.current,
  });
  // ===========================Print Functin End===========================================
  //=========================================ImgUploader===================================================
  const [selectedFile, setSelectedFile] = useState();
  const [preview, setPreview] = useState();

  useEffect(() => {
    if (!selectedFile) {
      setPreview(undefined);
      return;
    }

    const objectUrl = URL.createObjectURL(selectedFile);
    setPreview(objectUrl);
    return () => URL.revokeObjectURL(objectUrl);
  }, [selectedFile]);

  const onSelectFile = (e) => {
    if (!e.target.files || e.target.files.length === 0) {
      setSelectedFile(undefined);
      return;
    }

    // I've kept this example simple by using the first image instead of multiple
    setSelectedFile(e.target.files[0]);
  };
  //=========================================ImgUploader===================================================

  // Form Control Or data start=========================================================
  // ===========Add Language Start============

  const [languas, setlanguas] = React.useState([
    {
      text: "",
    },
  ]);

  const addlangua = (text) => {
    const newlanguas = [...languas, { text }];
    setlanguas(newlanguas);
  };

  const completelangua = (index) => {
    const newlanguas = [...languas];
    newlanguas[index].isCompleted = true;
    setlanguas(newlanguas);
  };

  const removelangua = (index) => {
    const newlanguas = [...languas];
    newlanguas.splice(index, 1);
    setlanguas(newlanguas);
  };
  const back_to_editor = (index_num) => {
    console.log("hello ", todoos[index_num]);
    // NexttoggleTab(2)
  };

  // ===========Add Language End==============

  function hello_kity() {
    let contact_info_list;
    if (localStorage.getItem("contact_info") === null) {
      contact_info_list = [];
    }
    else {
      contact_info_list = JSON.parse(localStorage.getItem("contact_info"));
    }
    let skill_list;
    if (localStorage.getItem("skill") === null) {
      skill_list = [];
    }
    else {
      skill_list = JSON.parse(localStorage.getItem("skill"));
    }


    let Language_list;
    if (localStorage.getItem("Language") === null) {
      skill_list = [];
    }
    else {
      Language_list = (JSON.parse(localStorage.getItem("Language")));
    }
    
    console.log("*************",contact_info_list)
    setState({
      ...state,
      name: contact_info_list['name'],
      LastName: contact_info_list['LastName'],
      occupation: contact_info_list['occupation'],
      aboutus: contact_info_list['aboutus'],
      email: contact_info_list['email'],
      address: contact_info_list['address'],
      phone: contact_info_list['phone'],
      date: contact_info_list['date'],
      nationality: contact_info_list['nationality'],
      link: contact_info_list['link'],
      Collage: contact_info_list['Collage'],
      Qualification: contact_info_list['Qualification'],
      CollageStart: contact_info_list['CollageStart'],
      CollageLast: contact_info_list['CollageLast'],
      Board: contact_info_list['Board'],
      AboutEDUCATION: contact_info_list['AboutEDUCATION'],
      skill: skill_list,
      Language: Language_list
    });
    console.log("state>>>>>>>>>",state)

    localStorage.setItem("contact_info_state", 'false')
    if (state !== "") {
      setIsActive(true);
    } else {
      setIsActive(false);
    }
    console.log("$$$$$$$$$$$$$",state)
  }
  // console.log('ras state', state)
  // Form Control Or data End=========================================================

  // BackGorund Change Start=======================
  const [mystyle, setmystyle] = useState({
    background: " #23476F",
  });

  const removeclass = () => {
    // Theammmmm
    document.getElementById("Theam").classList.remove("bg-primary");
    document.getElementById("Theam").classList.remove("bg-danger");
    document.getElementById("Theam").classList.remove("bg-success");
    document.getElementById("Theam").classList.remove("bg-secondary");
    document.getElementById("Theam").classList.remove("bg-warning");

    document.getElementById("Theammmmm").classList.remove("bg-primary");
    document.getElementById("Theammmmm").classList.remove("bg-danger");
    document.getElementById("Theammmmm").classList.remove("bg-success");
    document.getElementById("Theammmmm").classList.remove("bg-secondary");
    document.getElementById("Theammmmm").classList.remove("bg-warning");

    // Theam3

    document.getElementById("Theam3").classList.remove("bg-primary");
    document.getElementById("Theam3").classList.remove("bg-danger");
    document.getElementById("Theam3").classList.remove("bg-success");
    document.getElementById("Theam3").classList.remove("bg-secondary");
    document.getElementById("Theam3").classList.remove("bg-warning");

    // Theam4

    document.getElementById("Theam4").classList.remove("bg-primary");
    document.getElementById("Theam4").classList.remove("bg-danger");
    document.getElementById("Theam4").classList.remove("bg-success");
    document.getElementById("Theam4").classList.remove("bg-secondary");
    document.getElementById("Theam4").classList.remove("bg-warning");
    // Theam5

    document.getElementById("Theam5").classList.remove("bg-primary");
    document.getElementById("Theam5").classList.remove("bg-danger");
    document.getElementById("Theam5").classList.remove("bg-success");
    document.getElementById("Theam5").classList.remove("bg-secondary");
    document.getElementById("Theam5").classList.remove("bg-warning");

    document.getElementById("InnerButtonId").classList.remove("bg-warning");
    document.getElementById("InnerButtonId").classList.remove("bg-danger");
    document.getElementById("InnerButtonId").classList.remove("bg-success");
    document.getElementById("InnerButtonId").classList.remove("bg-secondary");
    document.getElementById("InnerButtonId").classList.remove("bg-warning");
  };
  const toggleChange = (cls) => {


    removeclass();

    // console.log(cls);
    document.getElementById("Theam").classList.add("bg-" + cls);
    document.getElementById("InnerButtonId").classList.add("bg-" + cls);
    document.getElementById("Theammmmm").classList.add("bg-" + cls);
    document.getElementById("Theam3").classList.add("bg-" + cls);
    document.getElementById("Theam4").classList.add("bg-" + cls);
    document.getElementById("Theam5").classList.add("bg-" + cls);

    //    document.body.classList.add('bg-' + cls);
    // document.getElementsByClassName('colorsection').classList('mystyle').add('background'+cls);
    // document.getElementsByClassName('colorsection').classList.add('background' + cls)
    if (mystyle.background === "#23476F") {
      setmystyle({
        bg: "red",
      });
    } else {
      setmystyle({
        bg: "#23476F",
      });
    }
  };

  // BackGorund Change  End=======================



  // ===============Add New section in the Experince Start================
  let initToodo;
  if (localStorage.getItem("todoos") === null) {
    initToodo = [];
  } else {
    initToodo = JSON.parse(localStorage.getItem("todoos"));
  }

  const ondDelete = (toddo) => {
    console.log("I am onddelete of toddo", toddo);

    setTodoos(
      todoos.filter((e) => {
        return e !== toddo;
      })
    );
    console.log("deleted", todoos);
    localStorage.setItem("todoos", JSON.stringify(todoos));
  };
  // localStorage.setItem("contact_info_state",'true')
  const adddTodo = (
    title,
    desc,
    companyname,
    Location,
    start,
    Last,
    AboutJob,
    isActive
  ) => {
    console.log("I am adding this toddo", title, desc);
    let sno;
    if (todoos.length === 0) {
      sno = 0;
    } else {
      sno = todoos[todoos.length - 1].sno + 1;
    }
    const myTodo = {
      sno: sno,
      title: title,
      desc: desc,
      companyname: companyname,
      Location: Location,
      start: start,
      Last: Last,
      AboutJob: AboutJob,
    };
    console.log("ghochun>>>>>>", AboutJob);
    setTodoos([...todoos, myTodo]);
    console.log(myTodo);
  };
  const [todoos, setTodoos] = useState(initToodo);
  useEffect(() => {
    localStorage.setItem("todoos", JSON.stringify(todoos));
  }, [todoos]);

  // ==========================================================progressbar=====================================

  const [countOfProgess, setCountOfProgess] = React.useState(10);

  // ========================================================end================================================

  // ===============Add New section in the Experince End================
  const [Tol, setTol] = useState(false);
  const target = useRef(null);

  const responsive = {
    0: { items: 1 },
    568: { items: 2 },
    1024: { items: 5 },
  };

  const items = [
    <div className="item" data-value="1">
      <li
        className={toggleState === 1 ? "tabs active-tabs" : "tabs"}
        onClick={() => toggleTab(1)}
      >
        <img
          src={temp1}
          alt=""
          style={{
            width: "150px",
            boxShadow:
              "rgba(0, 0, 0, 0.25) 0px 54px 55px, rgba(0, 0, 0, 0.12) 0px -12px 30px, rgba(0, 0, 0, 0.12) 0px 4px 6px, rgba(0, 0, 0, 0.17) 0px 12px 13px, rgba(0, 0, 0, 0.09) 0px -3px 5px",
          }}
        />
      </li>
    </div>,
    <div className="item" data-value="2">
      <li
        className={toggleState === 2 ? "tabs active-tabs" : "tabs"}
        onClick={() => toggleTab(2)}
      >
        <img
          src={template2}
          alt=""
          style={{
            width: "150px",
            boxShadow:
              "rgba(0, 0, 0, 0.25) 0px 54px 55px, rgba(0, 0, 0, 0.12) 0px -12px 30px, rgba(0, 0, 0, 0.12) 0px 4px 6px, rgba(0, 0, 0, 0.17) 0px 12px 13px, rgba(0, 0, 0, 0.09) 0px -3px 5px",
          }}
        />
      </li>
    </div>,
    <div className="item" data-value="3">
      <li
        className={toggleState === 3 ? "tabs active-tabs" : "tabs"}
        onClick={() => toggleTab(3)}
      >
        <img
          src={template3}
          alt=""
          style={{
            width: "150px",
            boxShadow:
              "rgba(0, 0, 0, 0.25) 0px 54px 55px, rgba(0, 0, 0, 0.12) 0px -12px 30px, rgba(0, 0, 0, 0.12) 0px 4px 6px, rgba(0, 0, 0, 0.17) 0px 12px 13px, rgba(0, 0, 0, 0.09) 0px -3px 5px",
          }}
        />
      </li>
    </div>,
    <div className="item" data-value="4">
      <li
        className={toggleState === 4 ? "tabs active-tabs" : "tabs"}
        onClick={() => toggleTab(4)}
      >
        <img
          src={template4}
          alt=""
          style={{
            width: "150px",
            boxShadow:
              "rgba(0, 0, 0, 0.25) 0px 54px 55px, rgba(0, 0, 0, 0.12) 0px -12px 30px, rgba(0, 0, 0, 0.12) 0px 4px 6px, rgba(0, 0, 0, 0.17) 0px 12px 13px, rgba(0, 0, 0, 0.09) 0px -3px 5px",
          }}
        />
      </li>
    </div>,
    <div className="item" data-value="5">
      <li
        className={toggleState === 5 ? "tabs active-tabs" : "tabs"}
        onClick={() => toggleTab(5)}
      >
        <img
          src={template5}
          alt=""
          style={{
            width: "150px",
            boxShadow:
              "rgba(0, 0, 0, 0.25) 0px 54px 55px, rgba(0, 0, 0, 0.12) 0px -12px 30px, rgba(0, 0, 0, 0.12) 0px 4px 6px, rgba(0, 0, 0, 0.17) 0px 12px 13px, rgba(0, 0, 0, 0.09) 0px -3px 5px",
          }}
        />
      </li>
    </div>,
    <div className="item" data-value="1">
      <li
        className={toggleState === 1 ? "tabs active-tabs" : "tabs"}
        onClick={() => toggleTab(1)}
      >
        <img
          src={temp1}
          alt=""
          style={{
            width: "150px",
            boxShadow:
              "rgba(0, 0, 0, 0.25) 0px 54px 55px, rgba(0, 0, 0, 0.12) 0px -12px 30px, rgba(0, 0, 0, 0.12) 0px 4px 6px, rgba(0, 0, 0, 0.17) 0px 12px 13px, rgba(0, 0, 0, 0.09) 0px -3px 5px",
          }}
        />
      </li>
    </div>,
    <div className="item" data-value="2">
      <li
        className={toggleState === 2 ? "tabs active-tabs" : "tabs"}
        onClick={() => toggleTab(2)}
      >
        <img
          src={template2}
          alt=""
          style={{
            width: "150px",
            boxShadow:
              "rgba(0, 0, 0, 0.25) 0px 54px 55px, rgba(0, 0, 0, 0.12) 0px -12px 30px, rgba(0, 0, 0, 0.12) 0px 4px 6px, rgba(0, 0, 0, 0.17) 0px 12px 13px, rgba(0, 0, 0, 0.09) 0px -3px 5px",
          }}
        />
      </li>
    </div>,
    <div className="item" data-value="3">
      <li
        className={toggleState === 3 ? "tabs active-tabs" : "tabs"}
        onClick={() => toggleTab(3)}
      >
        <img
          src={template3}
          alt=""
          style={{
            width: "150px",
            boxShadow:
              "rgba(0, 0, 0, 0.25) 0px 54px 55px, rgba(0, 0, 0, 0.12) 0px -12px 30px, rgba(0, 0, 0, 0.12) 0px 4px 6px, rgba(0, 0, 0, 0.17) 0px 12px 13px, rgba(0, 0, 0, 0.09) 0px -3px 5px",
          }}
        />
      </li>
    </div>,
    <div className="item" data-value="4">
      <li
        className={toggleState === 4 ? "tabs active-tabs" : "tabs"}
        onClick={() => toggleTab(4)}
      >
        <img
          src={template4}
          alt=""
          style={{
            width: "150px",
            boxShadow:
              "rgba(0, 0, 0, 0.25) 0px 54px 55px, rgba(0, 0, 0, 0.12) 0px -12px 30px, rgba(0, 0, 0, 0.12) 0px 4px 6px, rgba(0, 0, 0, 0.17) 0px 12px 13px, rgba(0, 0, 0, 0.09) 0px -3px 5px",
          }}
        />
      </li>
    </div>,
    <div className="item" data-value="5">
      <li
        className={toggleState === 5 ? "tabs active-tabs" : "tabs"}
        onClick={() => toggleTab(5)}
      >
        <img
          src={template5}
          alt=""
          style={{
            width: "150px",
            boxShadow:
              "rgba(0, 0, 0, 0.25) 0px 54px 55px, rgba(0, 0, 0, 0.12) 0px -12px 30px, rgba(0, 0, 0, 0.12) 0px 4px 6px, rgba(0, 0, 0, 0.17) 0px 12px 13px, rgba(0, 0, 0, 0.09) 0px -3px 5px",
          }}
        />
      </li>
    </div>,
  ];
  // Line Hight increment 
  const [Lineh, setLineh] = useState({
    lineHeight: 1.4,
    fontSize: "15px",
  })

  const fontweA = () => {
    setLineh({
      fontSize: "13px"
    })
  }
  const fontweB = () => {
    setLineh({
      fontSize: "15px"
    })
  }
  const fontweC = () => {
    setLineh({
      fontStyle: "17px"
    })
  }

  const incerment = () => {
    if (Lineh.lineHeight === 1.4) {
      setLineh({
        lineHeight: 1.6
      })
    }
    else if (Lineh.lineHeight === 1.6) {
      setLineh({
        lineHeight: 1.8
      });
    }
    else if (Lineh.lineHeight === 1) {
      setLineh({
        lineHeight: 1.2
      });
    }
    else if (Lineh.lineHeight === 1.2) {
      setLineh({
        lineHeight: 1.4
      });
    }
    else {
      setLineh({
        lineHeight: 2
      });
    }
  }
  const Decerment = () => {
    if (Lineh.lineHeight === 2) {
      setLineh({
        lineHeight: 1.8
      })
    }
    else if (Lineh.lineHeight === 1.8) {
      setLineh({
        lineHeight: 1.6
      });
    }
    else if (Lineh.lineHeight === 1.6) {
      setLineh({
        lineHeight: 1.4
      });
    }
    else if (Lineh.lineHeight === 1.4) {
      setLineh({
        lineHeight: 1.2
      });
    }
    else if (Lineh.lineHeight === 1.2) {
      setLineh({
        lineHeight: 1
      });
    }
  }
  const chkhis = () => {
    window.history.back()
  }
  return (
    <>

      <Container>
        <Offcanvas show={show} onHide={handleClose} placement="top">
          <Offcanvas.Header closeButton>
            <Offcanvas.Title></Offcanvas.Title>
          </Offcanvas.Header>
          <Offcanvas.Body>
            <ul className="tab-list">
              <AliceCarousel
                autoPlay
                autoPlayStrategy="none"
                autoPlayInterval={1000}
                animationDuration={1000}
                animationType="fadeout"
                mouseTracking
                items={items}
                responsive={responsive}
                controlsStrategy="alternate"
              />

            </ul>
          </Offcanvas.Body>
        </Offcanvas>

        <div className="show-content sdds-home">

      
        <div className="maindsdasd">
          <p className="ioxvxS">Document untitled</p>
          < ImCross onClick={chkhis} className="crossicons" />
          {/* <Link to="/editor" ></Link> */}
          <div className="buttos" >
            <button className="thisiss" onClick={handleShow}>
              <MdOutlineVibration
                id="fld"
                style={{
                  color: "#5a5e61",
                  fontSize: "24px",
                  marginRight: "5px",
                }}
              />
              Template
            </button>

            <div className="vchsdsd" style={{ marginLeft: "17px " }}>
              <AiOutlineBgColors style={{
                color: "#5a5e61",
                fontSize: "24px",
                marginRight: "5px",
              }} />
              {["bottom"].map((placement) => (
                <OverlayTrigger
                  trigger="focus"
                  key={placement}
                  placement={placement}
                  overlay={
                    <Popover id={`popover-positioned-${placement}`}>
                      <Popover.Header as="h3">{"Select Theam"}</Popover.Header>
                      <Popover.Body>
                        <div className="d-flex">
                          <div
                            className="bg-primary rounded mx-2"
                            // trigger="hover"
                            trigger="hover"
                            onClick={() => {
                              toggleChange("primary");
                            }}
                            style={{
                              height: "30px",
                              width: "30px",
                              cursor: "pointer",
                            }}
                          ></div>
                          <div
                            className="bg-danger rounded mx-2"
                            trigger="click"
                            onClick={() => {
                              toggleChange("danger");
                            }}
                            style={{
                              height: "30px",
                              width: "30px",
                              cursor: "danger",
                            }}
                          ></div>
                          <div
                            className="bg-success rounded mx-2"
                            trigger="click"
                            onClick={() => {
                              toggleChange("success");
                            }}
                            style={{
                              height: "30px",
                              width: "30px",
                              cursor: "pointer",
                            }}
                          ></div>
                          <div
                            className="bg-secondary rounded mx-2"
                            onClick={() => {
                              toggleChange("secondary");
                            }}
                            trigger="click"
                            style={{
                              height: "30px",
                              width: "30px",
                              cursor: "pointer",
                            }}
                          ></div>
                          <div
                            className="bg-warning rounded mx-2"
                            trigger="click"
                            onClick={() => {
                              toggleChange("warning");
                            }}
                            style={{
                              height: "30px",
                              width: "30px",
                              cursor: "pointer",
                            }}
                          ></div>
                        </div>
                      </Popover.Body>
                    </Popover>
                  }
                >
                  <Button id="ThemeButton">
                    <div className="InnerButton" id="InnerButtonId"></div>
                    <AiFillCaretDown id="down icons" />
                  </Button>
                </OverlayTrigger>
              ))}
            </div>
            <button className="thisissss" onClick={exportPDFWithComponent}>
              <GoDesktopDownload
                style={{
                  color: "#23476F",
                  fontSize: "24px",
                  marginRight: "5px",
                }}
              />
              Download
            </button>
            {/* <div className="vchsdsd" style={{ marginLeft: "17px " }}>
              <BiText style={{
                fontSize: "24px",
                marginRight: "5px",
                color: " #5a5e61",
              }} />
              <select className="thisiss" id="lkjkjhk">
                <option value="volvo" id="Saab">Classic</option>
                <option value="saab" id="Saab" >Modern</option>
                <option value="opel" id="Saab">Elegant</option>
                <option value="audi" id="Saab">Tech</option>
                <option value="audi" id="Saab">Professional</option>
              </select>
            </div> */}
            <div className="vchsdsd" style={{ marginLeft: "17px " }}>
              <MdTextFields style={{
                color: "#23476F",
                fontSize: "28px",
                marginTop: "-5px",
                color: " #5a5e61",
                marginRight: "5px",
              }} />
              <button onClick={fontweA} className="thisisss">
                Aa
              </button>
              <button onClick={fontweB} className="thisisss">
                <i> Aa </i>
              </button>
              <button onClick={fontweC} className="thisisss">
                <b> Aa </b>
              </button>
            </div>
            <div className="vchsdsd" style={{ marginLeft: "17px " }}>
              <MdOutlineFormatLineSpacing style={{
                color: "#23476F",
                fontSize: "28px",
                float: "left",
                color: " #5a5e61",
                marginTop: "10px",
                marginRight: "5px",
              }} />
              <div className="sc-1mr94c0-0 huAYAM">
                <button className="thisiss" onClick={Decerment}><HiMinus style={{ color: " #5a5e61", }} /></button>
                <button className="thisiss" disabled> <i> 1.5 </i></button>
                <button className="thisiss" onClick={incerment}><BsPlusLg style={{ color: " #5a5e61", }} /></button>
              </div>
            </div>
          </div>
        </div>
        <Container>

              <PDFExport
                ref={pdfExportComponent}
                paperSize="A4"
                fileName={`Report for ${new Date().getFullYear()}`}
                author="oblivisin Team"
              >
                {/* first******************************************************************************************* */}
                <div className="mainresume">
                  <div className={toggleState === 5 ? "content active-content" : "content"}>
                    <div className="resume" style={{ width: "100%" }}>
                      <Row>
                        <div className="djghsfds" id="Theammmmm"></div>
                        <Col md={12} lg={12} sm={12} xs={12} className="section" >
                          <div className="template-sec">
                            <div className="name-area">
                              <div className="d-flex">
                                <h4
                                  id="EXPERIENCE"
                                  data-placeholder="Chloe "
                                  className="mr-2 title template__section__info__value mr-3"

                                >
                                  {state.name}
                                </h4>
                                &nbsp;
                                <h4
                                  id="EXPERIENCE"
                                  data-placeholder=" "
                                  className="ml-2-cus title template__section__info__value"

                                >
                                  {state.LastName}
                                </h4>
                              </div>
                              <p
                                id="Occupation"
                                data-placeholder="Web Developer"

                              >
                                {state.occupation}
                              </p>
                              <p
                                className=" title template__section__info__value"
                                style={Lineh}
                                data-placeholder="Hey my name is pareep  and i am a web designer and developer ,  It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged'..."

                              >
                                {state.aboutus}
                              </p>
                            </div>

                            <hr />
                            <div className="forpadding-template-2">
                              <h5
                                className="template-2-heading"
                                style={{
                                  fontWeight: "300",
                                  fontSize: 12,
                                  borderBottom: "1px solid white",
                                }}
                              >
                                CONTACT INFORMATION
                              </h5>

                              <div className="d-flex">
                                <label htmlFor="text" id="lableColor">
                                  Email
                                </label>
                                <p
                                  className="email-cus"
                                  style={{
                                    fontWeight: "300",
                                    fontSize: 12,
                                  }}
                                >
                                  {state.Email}
                                </p>
                              </div>
                              <div className="d-flex">
                                <label htmlFor="text" id="lableColor">
                                  Phone
                                </label>
                                <p
                                  style={{
                                    fontWeight: "300",
                                    fontSize: 12,
                                  }}
                                >
                                  {state.phone}
                                </p>
                              </div>
                              <div className="d-flex">
                                <label htmlFor="text" id="lableColor">
                                  Date Of Birth
                                </label>
                                <p
                                  style={{
                                    fontWeight: "300",
                                    fontSize: 12,
                                  }}
                                >
                                  {state.date}
                                </p>
                              </div>
                              <div className="d-flex">
                                <label htmlFor="text" id="lableColor">
                                  Address
                                </label>
                                <p
                                  className=" title template__section__info__value"
                                  style={{
                                    fontWeight: "300",
                                    fontSize: 12,
                                  }}
                                >
                                  {state.address}
                                </p>
                              </div>
                              <div className="d-flex">
                                <label htmlFor="text" id="lableColor">
                                  Nationality
                                </label>
                                <p
                                  className="Nationality-cus"
                                  style={{
                                    fontWeight: "300",
                                    fontSize: 12,
                                  }}
                                >
                                  {state.Nationality}
                                </p>
                              </div>
                              <div className="d-flex">
                                <label htmlFor="text" id="lableColor">
                                  Link
                                </label>
                                <p
                                  style={{
                                    fontWeight: "300",
                                    fontSize: 12,
                                  }}
                                >
                                  {state.link}
                                </p>
                              </div>
                              <div className="d-flex">
                                <label htmlFor="text" id="lableColor">
                                  Language
                                </label>

                                <div className="template-two-Language">
                                  {JSON.parse(localStorage.getItem("language")).map((langua, index) => (
                                    <Language
                                      id="lableColor"
                                      key={index}
                                      index={index}
                                      langua={langua}
                                      completelangua={completelangua}
                                      removelangua={removelangua}
                                    />

                                  ))}
                                </div>
                              </div>

                              <div className="d-flex">
                                <label
                                  htmlFor="text"
                                  className=" title template__section__info__value"
                                  id="lableColor"
                                >
                                  Skill
                                </label>
                                <div className="template-two-skill">
                                  {JSON.parse(localStorage.getItem("skill")).map((Skilla, index) => {


                                    return <ADdSkill
                                      key={index}
                                      index={index}
                                      Skilla={Skilla.text}
                                      completeSkilla={completeSkilla}
                                      removeSkilla={removeSkilla}
                                    />
                                  }
                                  )}
                                </div>

                                <p
                                  style={{
                                    color: "white",
                                    fontWeight: "300",
                                    fontSize: 12,
                                  }}
                                >
                                  {state.Skill}
                                </p>
                              </div>

                              <div className="d-flex"></div>
                              <br />
                              <br />
                            </div>
                            <hr />
                            <div className="jobdetail">
                              <Row>
                                {/* <h5
                                  className="template-2-heading"
                                  id="EXPERIENCE"
                                >
                                  EXPERIENCE
                                </h5> */}
                                {/* <Col md={4} lg={4} sm={4} xs={4}>
                                  <p
                                    className=" title template__section__info__value"
                                    data-placeholder="Web Developer"

                                  >
                                    {state.Job}
                                  </p>
                                  <p
                                    className=" title template__section__info__value"
                                    id="Oblivision"
                                    data-placeholder="las vegas,Nevada"

                                  >
                                    {state.Location}
                                  </p>
                                  <p
                                    className=" title template__section__info__value"
                                    id="Oblivision"
                                    data-placeholder="Oblivision Technology"

                                  >
                                    {state.companyname}
                                  </p>

                                  <p>
                                    <input
                                      type="month"
                                      placeholder="March-21"
                                      value={state.Start}
                                      class="start"
                                    />
                                    <input
                                      type="month"
                                      placeholder="june-21"
                                      value={state.Last}
                                      class="start"
                                    />
                                  </p>
                                </Col> */}
                                <Col md={12} lg={12} sm={12} xs={12}>
                                   <h5
                                  className="template-2-heading"
                                  id="EXPERIENCE Theammmmm"
                                >
                                  EXPERIENCE
                                </h5>
                                    <Experince
                                      todoos={todoos}
                                      ondDelete={ondDelete}
                                    />
                                </Col>

                        <hr/>
                                <Col md={12} lg={12} sm={12} xs={12}>
                                   <h5
                                  className="template-2-heading"
                                  id="EXPERIENCE Theammmmm"
                                >
                                  Education
                                </h5>
                                      <Education
                                    Eduac={Eduac}
                                  // onDelete2={onDelete2}
                                  />
                                </Col>
                              </Row>
                              <hr />
                            </div>

                            <div className="eduacafsdd">
                              {/* <Row>
                                <h5 className="template-2-heading" id="EXPERIENCE">EDUCATION</h5>
                              </Row> */}
                              <hr />
                            </div>

                          </div>
                        </Col>
                      </Row>
                    </div>
                  </div>

                  <div className={toggleState === 2 ? "content active-content" : "content"}>
                    <div className="resume" style={{ width: "100%" }}>
                      <div className="newtanskdsld">
                        <Row>
                          <Col md={12} lg={12} sm={12} xs={12} className="section">
                            <Row>
                              <Col md={4} lg={4} sm={4} xs={4}>
                                <div className="sjghegkekEQW" id="Theam">
                                  <div className="d-flex"></div>
                                  <h4 className=" title template__section__info__value" style={{ color: "white" }} id="SHDSGD" data-placeholder="Chloe ">
                                    {state.name} {state.LastName}
                                  </h4>
                                  <p
                                    className=" title template__section__info__value"
                                    data-placeholder="Web Developer"
                                    style={{ color: "white" }}

                                  >
                                    {state.occupation}
                                  </p>
                                </div>
                              </Col>
                              <Col md={8} lg={8} sm={8} xs={8}>
                                <h5 id="EXPERIENCE">About</h5>
                                <p
                                  style={{Lineh}}
                                  className=" title template__section__info__value"
                                  data-placeholder="Hey my name is pareep  and i am a web designer and developer ,  It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged'..."

                                >
                                  {state.aboutus}
                                </p>
                              </Col>
                            </Row>
                            <Row>
                              <Col md={4} lg={4} sm={4} xs={4}>
                                <div className="icsndsaaa">
                                  <ImLocation2
                                    style={{
                                      color: "#23476F",
                                      fontSize: "30px",
                                      paddingBottom: "5px",
                                    }}
                                  />
                                  <p
                                    className=" title template__section__info__value"
                                    style={{
                                      color: "#23476F",
                                      fontWeight: "300",
                                      fontSize: 12,
                                    }}
                                  >
                                    {state.address}
                                  </p>
                                </div>
                                <div className="icsndsaaa">
                                  <BsTelephoneFill
                                    style={{
                                      color: "#23476F",
                                      fontSize: "30px",
                                      paddingBottom: "5px",
                                    }}
                                  />
                                  <p
                                    style={{
                                      fontWeight: "300",
                                      fontSize: 12,
                                      color: "#23476F",
                                    }}
                                  >
                                    {state.phone}
                                  </p>
                                </div>
                                <div className="icsndsaaa">
                                  <AiTwotoneMail
                                    style={{
                                      color: "#23476F",
                                      fontSize: "30px",
                                      paddingBottom: "5px",
                                    }}
                                  />
                                  <p
                                    className="email-cus"
                                    style={{
                                      fontWeight: "300",
                                      fontSize: 12,
                                      color: "#23476F",
                                    }}
                                  >
                                    {state.Email}
                                  </p>
                                </div>
                                <div className="icsndsaaa">
                                  <AiOutlineLink
                                    style={{
                                      color: "#23476F",
                                      fontSize: "30px",
                                      paddingBottom: "5px",
                                    }}
                                  />
                                  <p
                                    className="email-cus"
                                    style={{
                                      fontWeight: "300",
                                      fontSize: 12,
                                      color: "#23476F",
                                    }}
                                  >
                                    {state.link}
                                  </p>
                                </div>
                              </Col>
                              <Col md={8} lg={8} sm={8} xs={8}>
                                <h5 id="EXPERIENCE">EXPERIENCE</h5>
                                <div className="jobtitl">
                                  <Experince todoos={todoos}
                                  //  ondDelete={ondDelete} 
                                  />
                                </div>
                              </Col>
                            </Row>

                            <h5 id="EXPERIENCE">EDUCATION</h5>
                            <Education
                              Eduac={Eduac}
                              onDelete2={onDelete2}
                            />

                            <Row>
                              <Col md={6} sm={6} lg={6} sx={6}>
                                <h5
                                  className="template-2-heading"
                                  id="EXPERIENCE"
                                >
                                  Language
                                </h5>
                                <div className="template-two-Language">
                                  {JSON.parse(localStorage.getItem("language")).map((langua, index) => (
                                    <Language
                                      id="lableColor"
                                      key={index}
                                      index={index}
                                      langua={langua}
                                      completelangua={completelangua}
                                      removelangua={removelangua}
                                    />

                                  ))}
                                </div>
                              </Col>
                              <Col md={6} sm={6} lg={6} sx={6}>
                                <h5
                                  className="template-2-heading"
                                  id="EXPERIENCE"
                                >
                                  Skill
                                </h5>
                                <div className="template-two-skill">
                                  {JSON.parse(localStorage.getItem("skill")).map((Skilla, index) => {

                                    return <ADdSkill
                                      key={index}
                                      index={index}
                                      Skilla={Skilla.text}
                                      completeSkilla={completeSkilla}
                                      removeSkilla={removeSkilla}
                                    />
                                  }
                                  )}
                                </div>
                              </Col>
                            </Row>
                          </Col>
                        </Row>
                      </div>
                    </div>
                  </div>
                  <div
                    className={
                      toggleState === 3
                        ? "content active-content"
                        : "content"
                    }
                  >
                    <div className="resume" style={{ width: "100%" }}>
                      <Row>
                        <Col
                          md={12}
                          lg={12}
                          sm={12}
                          xs={12}
                          className="section"
                        >
                          <div className="thhirname-area" id="Theam3">
                            <Row>
                              <Col md={9}>
                                <div className="flex">
                                  <h4
                                    className=" title template__section__info__value"
                                    style={{ color: "white" }}
                                    id="ThirdName"
                                    data-placeholder="Chloe "

                                  >
                                    {state.name}
                                  </h4>
                                  <h4
                                    className=" title template__section__info__value"
                                    id="ThirdName"
                                    data-placeholder=" "

                                  >
                                    {state.LastName}
                                  </h4>
                                </div>
                                <p
                                  id="Occupation"
                                  className="OccupationThird"
                                  data-placeholder="Web Developer"

                                >
                                  {state.occupation}
                                </p>
                                <p
                                  className=" title template__section__info__value"
                                  // style={{ fontSize }}
                                  id="ThirdAbout"
                                  style={Lineh}
                                  data-placeholder="Hey my name is pareep  and i am a web designer and developer ,  It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged'..."

                                >
                                  {state.aboutus}
                                </p>
                              </Col>
                              <Col md={3}>
                                <div className="sixthImg">
                                  {localStorage.getItem('img') ?
                                    <img
                                      src={JSON.parse(localStorage.getItem('img')) ? JSON.parse(localStorage.getItem('img')) : null}
                                      alt="img panding"
                                    /> : <div></div>
                                  }
                                </div>
                              </Col>
                            </Row>
                          </div>
                          <div className="thirdgmail">
                            <Row>
                              <Col md={12} sm={12} lg={12} xs={12}>
                                <Row>
                                  <Col md={4} sm={4} lg={4} xs={4}>
                                    <label htmlFor="text" id="lableColor">
                                      Phone
                                    </label>
                                    <p
                                      style={{
                                        fontWeight: "300",
                                        fontSize: 12,
                                      }}
                                    >
                                      {state.phone}
                                    </p>
                                  </Col>
                                  <Col md={4} sm={4} lg={4} xs={4}>
                                    <label htmlFor="text" id="lableColor">
                                      Email
                                    </label>
                                    <p
                                      className="email-cus"
                                      style={{
                                        fontWeight: "300",
                                        fontSize: 12,
                                      }}
                                    >
                                      {state.Email}
                                    </p>
                                  </Col>
                                  <Col md={4} sm={4} lg={4} xs={4}>
                                    <label htmlFor="text" id="lableColor">
                                      Nationality
                                    </label>
                                    <p
                                      className="Nationality-cus"
                                      style={{
                                        fontWeight: "300",
                                        fontSize: 12,
                                      }}
                                    >
                                      {state.Nationality}
                                    </p>
                                  </Col>
                                </Row>
                              </Col>

                              <Col md={12} sm={12} lg={12} xs={12}>
                                <Row>
                                  <Col md={4} sm={4} lg={4} xs={4}>
                                    <label htmlFor="text" id="lableColor">
                                      Address
                                    </label>
                                    <p
                                      className=" title template__section__info__value"
                                      style={{
                                        fontWeight: "300",
                                        fontSize: 12,
                                      }}
                                    >
                                      {state.address}
                                    </p>
                                  </Col>
                                  <Col md={4} sm={4} lg={4} xs={4}>
                                    <label htmlFor="text" id="lableColor">
                                      Link
                                    </label>
                                    <p
                                      style={{
                                        fontWeight: "300",
                                        fontSize: 12,
                                      }}
                                    >
                                      {state.link}
                                    </p>
                                  </Col>
                                  <Col md={4} sm={4} lg={4} xs={4}>
                                    <label htmlFor="text" id="lableColor">
                                      Date Of Birth
                                    </label>
                                    <p
                                      style={{
                                        fontWeight: "300",
                                        fontSize: 12,
                                      }}
                                    >
                                      {state.date}
                                    </p>
                                  </Col>
                                </Row>
                              </Col>
                            </Row>
                          </div>
                          <div className="template-sec">
                            <div className="jobdetail">
                              <Row>
                                <h5
                                  className="template-2-heading"
                                  id="EXPERIENCE"
                                >
                                  EXPERIENCE
                                </h5>
                                <Experince
                                  todoos={todoos}
                                // ondDelete={ondDelete}
                                />
                              </Row>
                              <hr />
                            </div>
                            <hr />
                            <div className="forpadding-template-2">
                              {/* <div className="eduacafsdd">
                                <Row>
                                  <h5
                                    className="template-2-heading"
                                    id="EXPERIENCE"
                                  >
                                    EDUCATION
                                  </h5>
                                </Row>
                                <hr />
                              </div> */}
                              <div className="schooldsad">
                                <Row>
                                  <h5
                                    className="template-2-heading"
                                    id="EXPERIENCE"
                                  >
                                    EDUCATION
                                  </h5>
                                  <Education
                                    Eduac={Eduac}
                                  // onDelete2={onDelete2}
                                  />
                                  {/* <Todo
                                    todos={todos}
                                    onDelete={onDelete}
                                  /> */}
                                  <hr></hr>

                                </Row>
                              </div>
                              <div className="schooldsad">
                                <Row>
                                  <Col md={4} sm={4} lg={4} sx={4}>
                                    <h5
                                      className="template-2-heading"
                                      id="EXPERIENCE"
                                    >
                                      Language
                                    </h5>
                                    <div className="template-two-Language s-88">
                                      {JSON.parse(localStorage.getItem("language")).map((langua, index) => (
                                        <Language
                                          id="lableColor"
                                          key={index}
                                          index={index}
                                          langua={langua}
                                          completelangua={completelangua}
                                          removelangua={removelangua}
                                        />
                                      ))}
                                    </div>
                                  </Col>
                                  <Col md={8} sm={8} lg={8} sx={8}>
                                    <h5
                                      className="template-2-heading"
                                      id="EXPERIENCE"
                                    >
                                      Skill
                                    </h5>
                                    <div className="template-two-skill">
                                      {JSON.parse(localStorage.getItem("skill")).map((Skilla, index) => {


                                        return <ADdSkill
                                          key={index}
                                          index={index}
                                          Skilla={Skilla.text}
                                          completeSkilla={completeSkilla}
                                          removeSkilla={removeSkilla}
                                        />
                                      }
                                      )}
                                    </div>
                                  </Col>
                                </Row>
                              </div>

                              <br />
                              <br />
                            </div>
                            <hr />
                          </div>
                        </Col>
                      </Row>
                    </div>
                  </div>
                  <div
                    className={toggleState === 4 ? "content active-content" : "content"}
                  >
                    <div className="resume" style={{ width: "100%" }}>
                      <Row>
                        <Col md={12} sm={12} lg={12} sx={12}>
                          <div className="fifthHeader">
                            <div className="flex">
                              <h4
                                className="text-dark"
                                id="ThirdName"
                                data-placeholder="Chloe "

                              >
                                {state.name}
                              </h4>
                              <h4
                                className="  ml-2-cus"
                                id="ThirdName"
                                data-placeholder=" "

                              >
                                {state.LastName}
                              </h4>
                            </div>
                            <h5
                              className=" title template__section__info__value"
                              data-placeholder="Web Developer"

                            >
                              {state.occupation}
                            </h5>
                          </div>
                        </Col>

                        <Col md={12} sm={12} lg={12} sx={12}>
                          <div className="fifthSECHeader" id="Theam4">
                            <Row>
                              <Col md={8} sm={8} lf={8} sx={8}>
                                <h5 id="EXPERIENCE">About us</h5>
                                <p
                                  className=" title template__section__info__value"
                                  // style={{ fontSize }}
                                  id="ThirdAbout"
                                  style={Lineh}
                                  data-placeholder="Hey my name is pareep  and i am a web designer and developer ,  It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged'..."

                                >
                                  {state.aboutus}
                                </p>
                              </Col>
                              <Col md={4} sm={4} lf={4} sx={4}>
                                <div className="sixthImg">
                                  {localStorage.getItem('img') ?
                                    <img
                                      src={JSON.parse(localStorage.getItem('img')) ? JSON.parse(localStorage.getItem('img')) : null}
                                      alt="img panding"
                                    /> : <div></div>
                                  }
                                </div>
                              </Col>
                              <hr />
                              <Col md={4} sm={4} lg={4} xs={4}>
                                <label htmlFor="text" id="lableColor">
                                  Phone
                                </label>
                                <p
                                  style={{
                                    fontWeight: "300",
                                    fontSize: 12,
                                    color: "white",
                                  }}
                                >
                                  {state.phone}
                                </p>
                                <label htmlFor="text" id="lableColor">
                                  Date Of Birth
                                </label>
                                <p
                                  style={{
                                    fontWeight: "300",
                                    fontSize: 12,
                                    color: "white",
                                  }}
                                >
                                  {state.date}
                                </p>
                              </Col>
                              <Col md={4} sm={4} lg={4} xs={4}>
                                <label htmlFor="text" id="lableColor">
                                  Email
                                </label>
                                <p
                                  className="email-cus"
                                  style={{
                                    fontWeight: "300",
                                    fontSize: 12,
                                    color: "white",
                                  }}
                                >
                                  {state.Email}
                                </p>
                                <label htmlFor="text" id="lableColor">
                                  Address
                                </label>
                                <p
                                  className=" title template__section__info__value"
                                  style={{
                                    color: "white",
                                    fontWeight: "300",
                                    fontSize: 12,
                                  }}
                                >
                                  {state.address}
                                </p>
                              </Col>
                              <Col md={4} sm={4} lg={4} xs={4}>
                                <label htmlFor="text" id="lableColor">
                                  Nationality
                                </label>
                                <p
                                  className="Nationality-cus"
                                  style={{
                                    fontWeight: "300",
                                    color: "white",
                                    fontSize: 12,
                                  }}
                                >
                                  {state.Nationality}
                                </p>
                                <label htmlFor="text" id="lableColor">
                                  Link
                                </label>
                                <p
                                  style={{
                                    fontWeight: "300",
                                    fontSize: 12,
                                    color: "white",
                                  }}
                                >
                                  {state.link}
                                </p>
                              </Col>
                            </Row>
                          </div>
                        </Col>

                        <Col md={12} sm={12} lg={12} sx={12}>
                          <div className="workexp">
                            <Row>
                              <Col md={8} sm={8} lg={8} sx={8}>
                                <h5 id="EXPERIENCE">Work EXPERIENCE</h5>
                                <hr />
                                <Experince
                                  todoos={todoos}
                                // ondDelete={ondDelete}
                                />
                              </Col>
                              <Col md={4} sm={4} lg={4} sx={4}>
                                <Row>
                                  <Col md={12} sm={12} lg={12} sx={12}>
                                    <h5 id="EXPERIENCE">Skill</h5>
                                    <hr />
                                    <div className="template-two-skill">
                                      {JSON.parse(localStorage.getItem("skill")).map((Skilla, index) => {

                                        return <ADdSkill
                                          key={index}
                                          index={index}
                                          Skilla={Skilla.text}
                                          completeSkilla={completeSkilla}
                                          removeSkilla={removeSkilla}
                                        />
                                      }
                                      )}
                                    </div>
                                  </Col>

                                  <Col md={12} sm={12} lg={12} sx={12}>
                                    {/* <h5 id="EXPERIENCE">Language</h5> */}
                                    <hr />
                                    <div className="template-two-Language">
                                      {JSON.parse(localStorage.getItem("language")).map((langua, index) => (
                                        <Language
                                          id="lableColor"
                                          key={index}
                                          index={index}
                                          langua={langua}
                                          completelangua={completelangua}
                                          removelangua={removelangua}
                                        />

                                      ))}
                                    </div>
                                  </Col>
                                </Row>
                              </Col>
                            </Row>
                          </div>
                        </Col>

                        <Col md={12} sm={12} lg={12} sx={12}>
                          <hr />
                          <div className="fiftheduact">
                            <Row>
                              {/* <Col md={4} sm={4} lg={4} sx={4}>
                                <h5 id="EXPERIENCE">EDUCATION</h5>
                                <hr />

                              </Col> */}
                              <Col md={8} sm={8} lg={8} sx={8}>
                                <Education
                                  Eduac={Eduac}
                                // onDelete2={onDelete2}
                                />
                                {/* <Todo todos={todos} onDelete={onDelete} /> */}
                              </Col>
                            </Row>
                          </div>
                        </Col>
                      </Row>
                    </div>
                  </div>

                  <div className={toggleState === 1 ? "content active-content" : "content"}>
                    <div className="resume" style={{ width: "100%" }}>
                      <div className="sixthtemp" id="Theam5">
                        <div className=" text-white">
                          <p
                            className="temp-1-name title template__section__info__value"
                            id="ThirdName tmlfrs"
                          
                          >
                            {state.name}
                            &#160;
                            {state.LastName}
                          </p>
                        </div>
                        <p
                          data-placeholder="Web Developer"
                          className=" title template__section__info__value temp-1-occupation"
                          id="tmlfrs"
                        >
                          {state.occupation}
                        </p>
                        <div className="icons">
                          <Row>
                            <Col md={4} sm={4} lg={4} sx={4} className="mx-auto">
                              <div className="icsndsa">
                                <ImLocation2
                                  style={{
                                    color: "rgb(190, 155, 95)",
                                    fontSize: "20px",
                                    paddingBottom: "5px",
                                  }}
                                />
                                <p
                                  className=" title template__section__info__value"
                                  style={{
                                    color: "white",
                                    fontWeight: "300",
                                    fontSize: 10,
                                  }}
                                >
                                  {state.address}
                                </p>
                              </div>
                            </Col>
                            <Col md={4} sm={4} lg={4} sx={4}>
                              <div className="icsndsa">
                                <BsTelephoneFill
                                  style={{
                                    color: "rgb(190, 155, 95)",
                                    fontSize: "20px",
                                    paddingBottom: "5px",
                                  }}
                                />
                                <p
                                  style={{
                                    fontWeight: "300",
                                    fontSize: 10,
                                    color: "white",
                                  }}
                                >
                                  {state.phone}
                                </p>
                              </div>
                            </Col>
                            <Col md={4} sm={4} lg={4} sx={4}>
                              <div className="icsndsaa">
                                <AiTwotoneMail
                                  style={{
                                    color: "rgb(190, 155, 95)",
                                    fontSize: "20px",
                                    paddingBottom: "5px",
                                  }}
                                />
                                <p
                                  className="email-cus"
                                  style={{
                                    fontWeight: "300",
                                    padding: "0px 9px ",
                                    fontSize: 10,
                                    color: "white",
                                  }}
                                >
                                  {state.Email}
                                </p>
                              </div>
                            </Col>
                          </Row>
                        </div>
                      </div>



                      {/* </Col> */}

                      <table className="template__classical">  
                        <tbody>
                          <tr>
                            <td className="template__classical__column template__johannesburg__column">
                              <section className="profile_image_cus_1">
                                <p className="template__section__title--right"></p>
                                <div className="sixthImg" >
                                {localStorage.getItem('img') ?
                                  <img
                                    src={JSON.parse(localStorage.getItem('img')) ? JSON.parse(localStorage.getItem('img')) : null}
                                    alt="img panding"
                                  /> : <div></div>
                                }
                                  {/* {selectedFile && } */}
                                </div>
                              </section>
                              <section className="contact-information">
                                <p className="template__section__title template__section__title--right"></p>
                                <div className="d_o_b template__header__info template__header__info--birthday">
                                  <p className="template__section__subtitle">Date of Birth</p>
                                  <p className="  value-cus title template__section__info__value">
                                  {state.date}
                                  </p>
                                </div>
                                <div className="template__header__info template__header__info--nationality">
                                  <p className="template__section__subtitle">Nacionalitat</p>
                                  <p className="template__section__info__value ">
                                    {state.Nationality}
                                  </p>
                                </div>
                                <div className="template__header__info">
                                  <p className="template__section__subtitle">Link</p>
                                  <p className="template__section__info__value ">
                               
                                {state.link}
                                  </p>
                                </div>
                                <div className="template__header__info skill_cus_here">
                                  <p className="template__section__subtitle">Skill</p>
                                  <p className="template__section__info__value ">
                                  <div className="  title template__section__info__value  template-two-Language">
                                      {JSON.parse(localStorage.getItem("skill")).map((Skilla, index) => {
                                        return <ADdSkill
                                          key={index}
                                          index={index}
                                          Skilla={Skilla.text}
                                          completeSkilla={completeSkilla}
                                          removeSkilla={removeSkilla}
                                        />
                                      }
                                      )}
                                    </div>
                                  </p>
                                </div>
                                <div className="template__header__info Language_cus_here">
                                  <p className="template__section__subtitle">Language</p>
                                  <p className="template__section__info__value ">
                                  <div className="  title template__section__info__value template-two-Language">
                                      {JSON.parse(localStorage.getItem("language")).map((langua, index) => (
                                        <Language
                                          id="lableColor"
                                          key={index}
                                          index={index}
                                          langua={langua}
                                          completelangua={
                                            completelangua
                                          }
                                          removelangua={removelangua}
                                        />
                                      ))}
                                    </div>
                                  </p>
                                </div>
                              </section>
                            </td>
                            <td className="template__johannesburg__main template__classical__main">
                               <section className="discription_cus">
                                <p
                                  className=" title template__section__info__value  font-size--medium"

                                  id="sixdhgs"
                                  style={Lineh}
                                  data-placeholder="Hey my name is pareep  and i am a web designer and developer ,  It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged'..."
                                 
                                >
                                     {state.aboutus}
                                </p>
                              </section> 
                     
                              {/* {props.experince.map((item, index) =>
                                <section className="work-experience">
                                 
                                  <div className="template__section__container">
                                    <div className="template__section template__section__experience noValue">
                                      <div data-placeholder="SDFASFDaf" className="template__section__position">
                                        {state.title}
                                      </div>
                                      <div className="d-flex-cus-yg">
                                        <p className="template__section__company">
                                          {state.companyname}
                                        </p>
                                        <p className="template__section__location">
                                          {state.Location}
                                        </p>
                                      </div>
                                      <div className="template__section__date">
                                        <div className="template__section__endDate">{item.start}</div>
                                        <div className="template__section__startDate">
                                          {state.Last}
                                        </div>
                                      </div>
                                      <div class="template__section__description">
                                        {state.AboutJob}
                                      </div>
                                    </div>
                                  </div>
                                </section>
                              )} */}
                        <p className="template__section__title">
                                    <span>Work Experience</span>
                                  </p>
                               <Experince
                                 todoos={todoos}
                                />
                              {/* <section className="work-experience">
                               
                                {props.education.map((item, index) => (
                                  <div className="template__section__container">
                                    <div className="template__section template__section__experience noValue">
                                      <div className="template__section__position">
                                        {state.title}
                                      </div>
                                      <div className="d-flex-cus-yg">
                                        <p className="template__section__company">
                                          {state.Eduaction}

                                        </p>
                                        <p className="template__section__location">
                                          {state.schooll}

                                        </p>
                                      </div>
                                      <div className="template__section__date">
                                        <div className="template__section__endDate">{item.SDate}</div>
                                        <div className="template__section__startDate">
                                          {state.LDate}
                                        </div>
                                      </div>
                                      <div class="template__section__description" data-placeholder="- He organitzat i fet d'anfitrió d'actes de VIP amb
                              responsabilitat d'assistència a clients exclusius. - He
                              administrat estocs i col·laborat en el disseny de la
                              botiga. - He ofert mentoratge i traspàs de competències a
                              un equip de 8 assistents de compres.">
                                        {state.descc}

                                      </div>
                                    </div>
                                  </div>
                                ))}
                              </section> */}
                              <p className="template__section__title">
                                  <span>Education</span>
                                </p>
                             <Education
                                    Eduac={Eduac}
                                    // onDelete2={onDelete2}
                                  />

                            </td>
                          </tr>
                        </tbody>
                      </table>
                     
                      
                      {/* </Row> */}
                    </div>
                  </div>
                </div>
              </PDFExport>
           

        </Container>
        </div>
      </Container>
    </>
  );
};

export default NewComponent;